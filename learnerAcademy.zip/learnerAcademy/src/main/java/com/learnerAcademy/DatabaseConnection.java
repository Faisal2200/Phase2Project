package com.learnerAcademy;

import java.sql.*;

public class DatabaseConnection {
	
	public static Connection getConnection() throws SQLException, ClassNotFoundException{
		String driverClassName = "com.mysql.cj.jdbc.Driver";
		
		Class.forName(driverClassName);
		String url = "jdbc:mysql://localhost:3306/learneracademy?serverTimezone=UTC";
		String user = "root";
		String password = "faisal1420";
		Connection connection = DriverManager.getConnection(url, user, password);
		return connection;
	}
	
}
