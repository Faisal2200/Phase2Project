package com.learnerAcademy;

import javax.persistence.Embeddable;

@Embeddable
public class SubjectsAssignments {
	
	private String subjectName;
	private String subjectID;
	
	public String getSubjectName() {
		return subjectName;
	}
	
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	
	public String getSubjectID() {
		return subjectID;
	}
	
	public void setSubjectID(String subjectID) {
		this.subjectID = subjectID;
	}
	
}
