package com.learnerAcademy;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


@Entity
public class ClassesAssignments {
	
	@Id 
	@GeneratedValue
	private int classNumber;
	private String classID;
	private String className;
	private String classTime;
	
	@Embedded
	private SubjectsAssignments subjectsAssignments;
	
	public int getClassNumber() {
		return classNumber;
	}

	public void setClassNumber(int classNumber) {
		this.classNumber = classNumber;
	}

	public String getClassName() {
		return className;
	}
	
	public void setClassName(String className) {
		this.className = className;
	}
	
	public String getClassID() {
		return classID;
	}
	
	public void setClassID(String classID) {
		this.classID = classID;
	}
	
	public String getClassTime() {
		return classTime;
	}
	
	public void setClassTime(String classTime) {
		this.classTime = classTime;
	}
	
	public SubjectsAssignments getSubjectsAssignments() {
		return subjectsAssignments;
	}
	
	public void setSubjectsAssignments(SubjectsAssignments subjectsAssignments) {
		this.subjectsAssignments = subjectsAssignments;
	}
	
	
}
