package com.learnerAcademy;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class TeacherAssignments {
	
	@Id
	@GeneratedValue
	private int teacherNumber;
	private String teacherFirstName;
	private String teacherLastName;
	private String teacherID;
	
	@Embedded
	private ClassesToBeAssigned classesToBeAssigned;

	public int getTeacherNumber() {
		return teacherNumber;
	}

	public void setTeacherNumber(int teacherNumber) {
		this.teacherNumber = teacherNumber;
	}

	public String getTeacherFirstName() {
		return teacherFirstName;
	}

	public void setTeacherFirstName(String teacherFirstName) {
		this.teacherFirstName = teacherFirstName;
	}

	public String getTeacherLastName() {
		return teacherLastName;
	}

	public void setTeacherLastName(String teacherLastName) {
		this.teacherLastName = teacherLastName;
	}

	public String getTeacherID() {
		return teacherID;
	}

	public void setTeacherID(String teacherID) {
		this.teacherID = teacherID;
	}

	public ClassesToBeAssigned getClassesToBeAssigned() {
		return classesToBeAssigned;
	}

	public void setClassesToBeAssigned(ClassesToBeAssigned classesToBeAssigned) {
		this.classesToBeAssigned = classesToBeAssigned;
	}
	
	
}
