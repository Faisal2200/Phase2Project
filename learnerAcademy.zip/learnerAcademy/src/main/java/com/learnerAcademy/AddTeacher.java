package com.learnerAcademy;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/addTeacher")
public class AddTeacher extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		String teacherFirstName = request.getParameter("teacherFirstName");
		String teacherLastName = request.getParameter("teacherLastName");
		String teacherID = request.getParameter("teacherID");
		
		try{
			
			Connection connection = DatabaseConnection.getConnection();
			
			String INSERT_SQL = "insert into teachers(teacher_first_name, teacher_last_name, teacher_id) values(?,?,?)";
			
			PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SQL);
			
			preparedStatement.setString(1, teacherFirstName);
			preparedStatement.setString(2, teacherLastName);
			preparedStatement.setString(3, teacherID);
			
			preparedStatement.executeUpdate();
			
			out.println("<p>Teacher information added successfully</p>");
			out.println("<a href='home.html'><button>Return to home page</button></a>");
			
			connection.close();
			preparedStatement.close();
		
		}catch(SQLException e){
			e.printStackTrace();
		}catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}

}
