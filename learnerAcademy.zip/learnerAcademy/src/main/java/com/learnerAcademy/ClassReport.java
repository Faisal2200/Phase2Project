package com.learnerAcademy;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/classReport")
public class ClassReport extends HttpServlet {
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		String classID = request.getParameter("classID");
		
		String SELECT_SQL =  
				"select t.teacherID, t.teacherFirstName, t.teacherLastName, c.classID, c.className, c.classTime, "
				+ "c.subjectID, c.subjectName, s.student_id, s.student_name "
				+ "from teacherassignments t, classesassignments c, students s "
				+ "where c.classID = " + classID;
		try{
			Connection connection = DatabaseConnection.getConnection();
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(SELECT_SQL);
			
			if(!resultSet.isBeforeFirst()){
				out.println("<p>Class not found, please try again<p>");
			}else{
				
				out.println("<html>");
				out.println("<head>");
				out.println("<title>Class report</title>");
				out.println("<head>");
				out.println("<body>");
				out.println("<h2>Class Report</h2>");
				out.println("<hr/>");
				out.println("<table border='1'>");
				out.println("<tr>");
				out.println("<th>Teacher ID</th>");
				out.println("<th>Teacher First Name</th>");
				out.println("<th>Teacher Last Name</th>");
				out.println("<th>Class ID</th>");
				out.println("<th>Class Name</th>");
				out.println("<th>Class Time</th>");
				out.println("<th>Subject ID</th>");
				out.println("<th>Subject Name</th>");
				out.println("<th>Student ID</th>");
				out.println("<th>Student Name</th>");
				out.println("</tr>");
				
				while(resultSet.next()){
					out.println("<tr>");
					out.println("<td>"+ resultSet.getString("teacherID") +"</td>");
					out.println("<td>"+ resultSet.getString("teacherFirstName") +"</td>");
					out.println("<td>"+ resultSet.getString("teacherLastName") +"</td>");
					out.println("<td>"+ resultSet.getString("classID") +"</td>");
					out.println("<td>"+ resultSet.getString("className") +"</td>");
					out.println("<td>"+ resultSet.getString("classTime") +"</td>");
					out.println("<td>"+ resultSet.getString("subjectID") +"</td>");
					out.println("<td>"+ resultSet.getString("subjectName") +"</td>");
					out.println("<td>"+ resultSet.getString("student_id") +"</td>");
					out.println("<td>"+ resultSet.getString("student_name") +"</td>");
					out.println("</tr>");
				}
				out.println("</table>");
				out.println("<br/>");
				out.println("<a href='home.html'><button>Return to home page</button></a>");
				out.println("</body>");
				out.println("</html>");
				
			}
			
		}catch(SQLException e){
			e.printStackTrace();
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		
	}

}
