package com.learnerAcademy;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/addSubject")
public class AddSubject extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		String subjectName = request.getParameter("subjectName");
		String subjectID = request.getParameter("subjectID");
		
		try{
			
			Connection connection = DatabaseConnection.getConnection();
			
			String INSERT_SQL = "insert into subjects(subject_name, subject_id) values(?,?)";
			
			PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SQL);
			
			preparedStatement.setString(1, subjectName);
			preparedStatement.setString(2, subjectID);
			
			preparedStatement.executeUpdate();
			
			out.println("<p>Subject added successfully</p>");
			out.println("<a href='home.html'><button>Return to home page</button></a>");
			
			connection.close();
			preparedStatement.close();
		
		}catch(SQLException e){
			e.printStackTrace();
		}catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

}
