package com.learnerAcademy;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Students {
	
	@Id
	@GeneratedValue
	private int student_number;
	private String student_id;
	private String student_name;
	
	@Embedded
	private ClassesToBeAssigned classesToBeAssigned;

	public int getStudent_number() {
		return student_number;
	}

	public void setStudent_number(int student_number) {
		this.student_number = student_number;
	}

	public String getStudent_name() {
		return student_name;
	}

	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}

	public String getStudent_id() {
		return student_id;
	}

	public void setStudent_id(String student_id) {
		this.student_id = student_id;
	}

	public ClassesToBeAssigned getClassesToBeAssigned() {
		return classesToBeAssigned;
	}

	public void setClassesToBeAssigned(ClassesToBeAssigned classesToBeAssigned) {
		this.classesToBeAssigned = classesToBeAssigned;
	}
	
	
}
