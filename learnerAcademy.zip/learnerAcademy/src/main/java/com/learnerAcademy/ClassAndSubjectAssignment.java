package com.learnerAcademy;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/classAndSubjectAssignment")
public class ClassAndSubjectAssignment extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		String className = request.getParameter("className");
		String classID = request.getParameter("classID");
		String classTime = request.getParameter("classTime");
		String subjectName = request.getParameter("subjectName");
		String subjectID = request.getParameter("subjectID");
		
		Configuration configuration = new Configuration().configure();
		configuration.addAnnotatedClass(ClassesAssignments.class);
		StandardServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
		SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		
		SubjectsAssignments subjectAssignments = new SubjectsAssignments();
		ClassesAssignments classesAssignments = new ClassesAssignments();
		
		
		
		subjectAssignments.setSubjectName(subjectName);
		subjectAssignments.setSubjectID(subjectID);
		
		classesAssignments.setClassName(className);
		classesAssignments.setClassID(classID);
		classesAssignments.setClassTime(classTime);
		
		classesAssignments.setSubjectsAssignments(subjectAssignments);
		
		session.save(classesAssignments);
		
		session.flush();
		session.getTransaction().commit();
		session.close();
		sessionFactory.close();
		
		out.println("<p>Class assigned to subject successfully</p>");
		
	}

}
