package com.learnerAcademy;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/viewClasses")
public class ViewClasses extends HttpServlet {
	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		String SELECT_SQL = "select * from classes";
		
		try{
			
			Connection connection = DatabaseConnection.getConnection();
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(SELECT_SQL);
			
			response.setContentType("text/html");
			
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Classes list</title>");
			out.println("<head>");
			out.println("<body>");
			out.println("<h2>Classes list</h2>");
			out.println("<hr/>");
			out.println("<table border='1'>");
			out.println("<tr>");
			out.println("<th>Class Name</th>");
			out.println("<th>Class ID</th>");
			out.println("<th>Class Time</th>");
			out.println("</tr>");
			
			while(resultSet.next()){
				out.println("<tr>");
				out.println("<td>"+ resultSet.getString("class_name") +"</td>");
				out.println("<td>"+ resultSet.getString("class_id") +"</td>");
				out.println("<td>"+ resultSet.getString("class_time") +"</td>");
				out.println("</tr>");
			}
			out.println("</table>");
			out.println("<br/>");
			out.println("<a href='home.html'><button>Return to home page</button></a>");
			out.println("</body>");
			out.println("</html>");
			
		}catch(SQLException e){
			e.printStackTrace();
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}	
		
	}

}
