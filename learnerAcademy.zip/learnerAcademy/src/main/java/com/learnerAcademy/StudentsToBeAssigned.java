package com.learnerAcademy;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

/**
 * Servlet implementation class StudentsToBeAssigned
 */
public class StudentsToBeAssigned extends HttpServlet {
	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		Configuration configuration = new Configuration().configure();
		configuration.addAnnotatedClass(Students.class);
		StandardServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
		SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		
		ClassesToBeAssigned classesToBeAssigned = new ClassesToBeAssigned();
		Students students = new Students();
		
		classesToBeAssigned.setClassName("class3");
		classesToBeAssigned.setClassID("113");
		classesToBeAssigned.setClassTime("10:00AM");
		
		students.setStudent_id("212");
		students.setStudent_name("Mohammed");
		
		students.setClassesToBeAssigned(classesToBeAssigned);
		
		session.save(students);
		
		session.flush();
		session.getTransaction().commit();
		session.close();
		sessionFactory.close();
		
		out.println("<p>Student added successfully</p>");
		
		
	}

}
