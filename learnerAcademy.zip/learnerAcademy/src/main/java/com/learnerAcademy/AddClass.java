package com.learnerAcademy;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/addClass")
public class AddClass extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		String className = request.getParameter("className");
		String classID = request.getParameter("classID");
		String classTime = request.getParameter("classTime");
		
		try{
			
			Connection connection = DatabaseConnection.getConnection();
			
			String INSERT_SQL = "insert into classes(class_name, class_id, class_time) values(?,?,?)";
			
			PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SQL);
			
			preparedStatement.setString(1, className);
			preparedStatement.setString(2, classID);
			preparedStatement.setString(3, classTime);
			
			preparedStatement.executeUpdate();
			
			out.println("<p>Class added successfully</p>");
			out.println("<a href='home.html'><button>Return to home page</button></a>");
			
			connection.close();
			preparedStatement.close();
		
		}catch(SQLException e){
			e.printStackTrace();
		}catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

}
