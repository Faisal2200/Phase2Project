package com.learnerAcademy;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

@WebServlet("/teacherAndClassesAssignments")
public class TeachersAndClassesAssignments extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		String teacherFirstName = request.getParameter("teacherFirstName");
		String teacherLastName = request.getParameter("teacherLastName");
		String teacherID = request.getParameter("teacherID");
		String className = request.getParameter("className");
		String classID = request.getParameter("classID");
		String classTime = request.getParameter("classTime");
		
		Configuration configuration = new Configuration().configure();
		configuration.addAnnotatedClass(TeacherAssignments.class);
		StandardServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
		SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		
		ClassesToBeAssigned classesToBeAssigned = new ClassesToBeAssigned();
		TeacherAssignments teacherAssignments = new TeacherAssignments();
		
		classesToBeAssigned.setClassName(className);
		classesToBeAssigned.setClassID(classID);
		classesToBeAssigned.setClassTime(classTime);
		
		teacherAssignments.setTeacherFirstName(teacherFirstName);
		teacherAssignments.setTeacherLastName(teacherLastName);
		teacherAssignments.setTeacherID(teacherID);
		
		teacherAssignments.setClassesToBeAssigned(classesToBeAssigned);
		
		session.save(teacherAssignments);
		
		session.flush();
		session.getTransaction().commit();
		session.close();
		sessionFactory.close();
		
		out.println("<p>Teacher assigned to class successfully</p>");
		
	}

}
